Contributors
------------

People who contributed to the seL4 code, design, or documentation in this
repository (in alphabetical order).

* June Andronick, NICTA & UNSW
* Ali Akguel, NICTA
* Joel Beeren, NICTA
* Bernard Blackham, NICTA & UNSW
* Timothy Bourke, NICTA
* Andrew Boyton, NICTA & UNSW
* Matthew Brassil, NICTA
* Aleksander Budzynowski, NICTA & UNSW
* Manuel Chakravarty, NICTA & UNSW
* Xi Ma Chen, NICTA
* Nahida Chowdhury, NICTA
* Peter Chubb, NICTA
* David Cock, NICTA & UNSW
* Adrian Danis, NICTA
* Matthias Daum, NICTA & UNSW
* Philip Derrin, NICTA
* Dhammika Elkaduwe, NICTA & UNSW
* Kevin Elphinstone, NICTA & UNSW
* Matthew Fernandez, NICTA & UNSW
* Peter Gammie, NICTA
* Xin Gao, NICTA
* David Greenaway, NICTA & UNSW
* Matthew Grosvenor, NICTA
* Lukas Haenel, NICTA
* Gernot Heiser, NICTA & UNSW
* Benjamin Kalman, NICTA
* Justin King-Lacroix, NICTA
* Gerwin Klein, NICTA & UNSW
* Rafal Kolanski, NICTA & UNSW
* Alexander Kroh, NICTA
* Etienne Le Sueur, NICTA & UNSW
* Corey Lewis, NICTA
* Japheth Lim, NICTA
* Anna Lyons, NICTA & UNSW
* Stephanie McArthur, NICTA
* Sam McNally, NICTA
* Tim Newsham
* Toby Murray, NICTA & UNSW
* Ameya Palande, NICTA
* Max R.D. Parmer
* Sean Peters, NICTA
* Simon Rodgers, NICTA
* Wink Saville
* Sean Seefried, NICTA
* Thomas Sewell, NICTA & UNSW
* Stephen Sherratt, NICTA
* Michael von Tessin, NICTA & UNSW
* Robbie Van Vossen, Dornerworks
* Adam Walker, NICTA
* James Wilmot, NICTA
* Simon Winwood, NICTA
* Jiawei Xie, NICTA
